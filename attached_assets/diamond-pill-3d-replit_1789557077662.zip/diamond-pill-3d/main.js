import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

const canvas = document.querySelector('#scene');

const renderer = new THREE.WebGLRenderer({
  canvas,
  antialias: true,
  alpha: false,
  powerPreference: 'high-performance'
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight, false);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.25;
renderer.setClearColor(0x000000, 1);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000);

const camera = new THREE.PerspectiveCamera(36, window.innerWidth / window.innerHeight, 0.1, 100);
camera.position.set(0, 0.15, 7.2);

const pmrem = new THREE.PMREMGenerator(renderer);
const room = new RoomEnvironment(renderer);
scene.environment = pmrem.fromScene(room, 0.03).texture;
room.dispose();
pmrem.dispose();

const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene, camera));
const bloom = new UnrealBloomPass(
  new THREE.Vector2(window.innerWidth, window.innerHeight),
  0.85,
  0.7,
  0.9
);
composer.addPass(bloom);

const pill = new THREE.Group();
scene.add(pill);

// Faceted capsule body
const bodyGeometry = new THREE.CapsuleGeometry(1.05, 2.35, 10, 20);
bodyGeometry.rotateZ(Math.PI / 2);

const diamondMaterial = new THREE.MeshPhysicalMaterial({
  color: 0xffffff,
  metalness: 0.0,
  roughness: 0.035,
  transmission: 1.0,
  thickness: 1.6,
  ior: 2.38,
  clearcoat: 1.0,
  clearcoatRoughness: 0.02,
  envMapIntensity: 3.0,
  iridescence: 1.0,
  iridescenceIOR: 1.35,
  iridescenceThicknessRange: [120, 850],
  dispersion: 0.95,
  transparent: true,
  opacity: 0.98,
  flatShading: true
});

const body = new THREE.Mesh(bodyGeometry, diamondMaterial);
pill.add(body);

// Narrow center ring for the capsule seam
const ringGeometry = new THREE.TorusGeometry(1.055, 0.035, 10, 48);
ringGeometry.rotateY(Math.PI / 2);
const ringMaterial = new THREE.MeshPhysicalMaterial({
  color: 0xffffff,
  metalness: 0.35,
  roughness: 0.04,
  transmission: 0.5,
  thickness: 0.25,
  ior: 2.1,
  clearcoat: 1,
  envMapIntensity: 3.5
});
const ring = new THREE.Mesh(ringGeometry, ringMaterial);
pill.add(ring);

// Subtle inner glow core so the crystal stays alive on a black page.
const coreGeometry = new THREE.CapsuleGeometry(0.58, 1.75, 8, 16);
coreGeometry.rotateZ(Math.PI / 2);
const coreMaterial = new THREE.MeshBasicMaterial({
  color: 0x9fdfff,
  transparent: true,
  opacity: 0.028,
  blending: THREE.AdditiveBlending,
  depthWrite: false
});
pill.add(new THREE.Mesh(coreGeometry, coreMaterial));

pill.rotation.set(-0.22, 0.35, -0.58);
pill.position.y = 0.12;

// Studio lights placed around the object create moving diamond fire.
const keyLight = new THREE.PointLight(0xffffff, 150, 30, 1.5);
keyLight.position.set(4.5, 4, 5);
scene.add(keyLight);

const rimLight = new THREE.PointLight(0x8bc7ff, 120, 25, 1.8);
rimLight.position.set(-4.5, -1.5, 3.5);
scene.add(rimLight);

const warmLight = new THREE.PointLight(0xffb15a, 105, 25, 1.7);
warmLight.position.set(1.5, -4, 2.5);
scene.add(warmLight);

const violetLight = new THREE.PointLight(0xa76dff, 85, 20, 1.8);
violetLight.position.set(-2.5, 3.2, 1.0);
scene.add(violetLight);

// Reflection plane, nearly invisible except for the light caught beneath the pill.
const floorMaterial = new THREE.MeshPhysicalMaterial({
  color: 0x050505,
  metalness: 0.25,
  roughness: 0.22,
  transparent: true,
  opacity: 0.42,
  clearcoat: 1,
  clearcoatRoughness: 0.1
});
const floor = new THREE.Mesh(new THREE.PlaneGeometry(18, 18), floorMaterial);
floor.rotation.x = -Math.PI / 2;
floor.position.y = -2.0;
scene.add(floor);

// Soft ellipse under the pill.
const shadowTexture = (() => {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const ctx = c.getContext('2d');
  const g = ctx.createRadialGradient(128, 128, 0, 128, 128, 128);
  g.addColorStop(0, 'rgba(255,255,255,0.13)');
  g.addColorStop(0.35, 'rgba(160,200,255,0.055)');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 256, 256);
  return new THREE.CanvasTexture(c);
})();
const glow = new THREE.Mesh(
  new THREE.PlaneGeometry(5.4, 2.7),
  new THREE.MeshBasicMaterial({
    map: shadowTexture,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    opacity: 0.8
  })
);
glow.rotation.x = -Math.PI / 2;
glow.position.y = -1.97;
scene.add(glow);

// Star-like sparkles around the crystal.
function makeSparkleTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const ctx = c.getContext('2d');
  ctx.translate(128, 128);

  const radial = ctx.createRadialGradient(0, 0, 0, 0, 0, 45);
  radial.addColorStop(0, 'rgba(255,255,255,1)');
  radial.addColorStop(0.15, 'rgba(255,255,255,0.9)');
  radial.addColorStop(0.45, 'rgba(170,210,255,0.35)');
  radial.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = radial;
  ctx.beginPath();
  ctx.arc(0, 0, 45, 0, Math.PI * 2);
  ctx.fill();

  const line = ctx.createLinearGradient(-128, 0, 128, 0);
  line.addColorStop(0, 'rgba(255,255,255,0)');
  line.addColorStop(0.5, 'rgba(255,255,255,0.95)');
  line.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = line;
  ctx.fillRect(-128, -1.5, 256, 3);
  ctx.rotate(Math.PI / 2);
  ctx.fillRect(-128, -1.5, 256, 3);

  return new THREE.CanvasTexture(c);
}

const sparkleTexture = makeSparkleTexture();
const sparklePositions = [
  [-1.75, 0.65, 0.95],
  [1.8, 0.65, 0.8],
  [0.55, 1.18, 0.65],
  [-0.65, -0.85, 0.72],
  [1.15, -0.3, 0.95]
];
const sparkles = sparklePositions.map((p, i) => {
  const material = new THREE.SpriteMaterial({
    map: sparkleTexture,
    color: 0xffffff,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    opacity: 0.9
  });
  const sprite = new THREE.Sprite(material);
  sprite.position.set(...p);
  const s = 0.28 + i * 0.025;
  sprite.scale.set(s, s, 1);
  pill.add(sprite);
  return sprite;
});

let pointerX = 0;
let pointerY = 0;
let targetX = 0;
let targetY = 0;

window.addEventListener('pointermove', (event) => {
  targetX = (event.clientX / window.innerWidth - 0.5) * 2;
  targetY = (event.clientY / window.innerHeight - 0.5) * 2;
});

const clock = new THREE.Clock();

function animate() {
  const t = clock.getElapsedTime();

  pointerX += (targetX - pointerX) * 0.035;
  pointerY += (targetY - pointerY) * 0.035;

  // Slow floating and rotation.
  pill.rotation.x = -0.22 + Math.sin(t * 0.38) * 0.06 + pointerY * 0.08;
  pill.rotation.y = 0.35 + t * 0.22 + pointerX * 0.12;
  pill.rotation.z = -0.58 + Math.sin(t * 0.26) * 0.08;
  pill.position.y = 0.12 + Math.sin(t * 0.85) * 0.12;

  // Move the lights just enough to make facets flicker.
  keyLight.position.x = 4.5 + Math.sin(t * 0.7) * 1.4;
  keyLight.position.y = 3.8 + Math.cos(t * 0.5) * 1.0;
  rimLight.position.y = -1.4 + Math.sin(t * 0.6 + 1.5) * 1.6;
  warmLight.position.x = 1.5 + Math.cos(t * 0.45) * 2.2;
  violetLight.position.x = -2.5 + Math.sin(t * 0.55) * 1.5;

  sparkles.forEach((sprite, i) => {
    const pulse = 0.65 + Math.sin(t * (2.2 + i * 0.18) + i) * 0.35;
    sprite.material.opacity = Math.max(0.08, pulse);
    const s = (0.26 + i * 0.022) * (0.88 + pulse * 0.26);
    sprite.scale.set(s, s, 1);
  });

  glow.material.opacity = 0.62 + Math.sin(t * 0.9) * 0.1;

  composer.render();
  requestAnimationFrame(animate);
}

animate();

function resize() {
  const width = window.innerWidth;
  const height = window.innerHeight;
  renderer.setSize(width, height, false);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  composer.setSize(width, height);
}

window.addEventListener('resize', resize);
