# Diamond Pill 3D

Minimal full-screen Three.js website for Replit.

## Run in Replit

1. Upload the project files (or unzip the ZIP).
2. Open Shell.
3. Run:

```bash
npm install
npm run dev
```

Replit will expose the Vite web preview automatically.

## What it does

- Pure black full-screen background
- Real-time 3D diamond/crystal pill
- Slow floating rotation
- Mouse/touch parallax
- Diamond-like refraction and iridescence
- Moving studio lights
- Bloom and sparkle effects
- No buttons, navigation, text, or UI
